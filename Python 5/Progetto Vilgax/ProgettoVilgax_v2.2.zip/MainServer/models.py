class Preghiera:
    def __init__(self, titolo:str, testo:str, data:int) -> None:
        self.titolo = titolo
        self.testo = testo
        self.data = data