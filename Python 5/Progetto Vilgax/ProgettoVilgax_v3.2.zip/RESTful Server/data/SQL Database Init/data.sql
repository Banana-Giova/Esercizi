INSERT INTO Recensioni (id, proprietario, descrizione, voto)
VALUES
(0, 'MarisaVolponiC','Mi piace poco','2'),
(1, 'DanielonePietrosmusiC','Vilgax mi padre','5'),
(2, 'MicheloneBadasiumS','Le patatine le fanno meglio a Tor Bella Monaca','1'),
(3, 'RichardBensonC','io volevo un pollo. UN POLLOOOOOOOOOOOOOOOO','4');

INSERT INTO Vittime (id, nome, cognome, paprika)
VALUES
('JosephineSilverwolfC','Josephine','Silverwolf','con'),
('MarisaVolponiC','Marisa','Volponi','con'),
('MicheloneBadasiumS','Michelone','Badasium','senza'),
('RichardBensonC','Richard','Benson','con'),
('DanielonePietrosmusiC','Danielone','Pietrosmusi','con');

INSERT INTO Preghiere (proprietario, titolo, contenuto, data)
VALUES
('DanielonePietrosmusiC','Odio l''Estonia','Vilgax distruggi l''Estonia grazie',20241018),
('JosephineSilverwolfC','I gonfaloni','Vorrei gonfaloni infiniti, grazie',20240920),
('JosephineSilverwolfC','L''amore ai tempi del sium','Quando ero giovane il sium non c''era. Ora le cose sono cambiate',20240921),
('MarisaVolponiC','L''amore infinito','TI ASPETTO ALLA SOLITA PANCHINA.',20240921),
('RichardBensonC','Un pollo','Vilgax io volevo un pollo, devo sacrificarlo a te, dammi un pollo per piacere',20241004),
('RichardBensonC','grazie del pollo','davvero un pollo di qualit\u00e0 sono soddisfatto',20241004),
('RichardBensonC','I NANI','VOGLIO ANCHE DEI NANI VILGAX; PORTAMI DEI NANI',20241004);