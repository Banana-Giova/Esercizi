package main;
@FunctionalInterface
interface VerificatorePari {
    boolean verifica(int numero);
}