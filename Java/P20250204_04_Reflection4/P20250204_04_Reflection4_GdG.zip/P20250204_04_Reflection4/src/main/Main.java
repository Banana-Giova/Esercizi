package main;
import models.CarExtractor;

public class Main {

	public static void main(String[] args) {
		CarExtractor carex = new CarExtractor();
		carex.carExtractor();
	}

}
