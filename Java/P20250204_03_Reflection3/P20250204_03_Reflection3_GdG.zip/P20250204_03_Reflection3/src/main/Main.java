package main;
import models.*;

public class Main {

	public static void main(String[] args) {
		AnimalExtractor animex = new AnimalExtractor();
		animex.animalExtractor();
	}

}
