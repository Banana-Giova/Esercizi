package main;
@FunctionalInterface
interface CalcolatorePotenza {
    int calcola(int base, int esponente);
}