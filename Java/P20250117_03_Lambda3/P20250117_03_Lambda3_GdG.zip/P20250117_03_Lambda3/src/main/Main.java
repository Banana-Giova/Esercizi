package main;
public class Main {

	public static void main(String[] args) {
		CalcolatoreArea calcarea = (ray) -> 3.14*(ray*ray);
		System.out.println(calcarea.calcola(8));
	}

}
