package main;
@FunctionalInterface
interface CalcolatoreArea {
	double calcola(double raggio);

}
