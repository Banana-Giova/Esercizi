public class Main {

	public static void main(String[] args) {
		TryCatchFinally tfc = new TryCatchFinally(1000);
		tfc.start();
	}

}
