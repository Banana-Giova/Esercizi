package main;
@FunctionalInterface
interface VerificatoreParola {
	boolean verifica(String stringa);
}