package threads;

public class ThreadRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("Sono un thread che implementa Runnable");
		
	}
	
}
