package threads;

public class ThreadExtend extends Thread {
	
	public void run() {
		System.out.println("Sono un thread che estende Thread");
	}
}
