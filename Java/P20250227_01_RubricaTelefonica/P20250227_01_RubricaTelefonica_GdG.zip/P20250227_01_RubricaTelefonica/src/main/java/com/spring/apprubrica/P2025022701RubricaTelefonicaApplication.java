package com.spring.apprubrica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P2025022701RubricaTelefonicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(P2025022701RubricaTelefonicaApplication.class, args);
	}

}
