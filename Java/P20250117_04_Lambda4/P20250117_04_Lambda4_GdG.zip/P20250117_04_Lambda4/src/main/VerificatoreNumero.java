package main;
@FunctionalInterface
interface VerificatoreNumero {
    boolean verifica(int numero);
}