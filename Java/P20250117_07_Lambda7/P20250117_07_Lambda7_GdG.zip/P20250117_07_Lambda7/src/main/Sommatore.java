package main;
import java.util.*;

@FunctionalInterface
interface Sommatore {
	int sommatore(List<Integer> lista);
}