package models;

public class NumeroPari {
	public static boolean numeroPari(int numero) {
		return (numero % 2 == 0);
	}
}
