package models;

public class Calcolatrice {
		
	public static int somma(int a, int b) {
		return a + b;
	}
	public static int sottrazione(int a, int b) {
		return a - b;
	}
	public static int moltiplicazione(int a, int b) {
		return a * b;
	}
	public static double divisione(int a, int b) {
		return (double)a / (double)b;
	}
}