package main;
import java.util.*;

@FunctionalInterface
interface OrdinaLista {
	List<String> ordina(List<String> lista);
}