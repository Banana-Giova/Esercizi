package main;
import java.util.*;

@FunctionalInterface
interface CalcolatoreMedia {
	double calcola(List<Integer> lista);
}