@FunctionalInterface
interface Calcolatore {

    int calcola(int a, int b);

}
