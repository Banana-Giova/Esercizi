public class Main {

	public static void main(String[] args) {
		Calcolatore calc = (a,b) -> a+b;;
		System.out.println(calc.calcola(16, 31));
	}

}
