package com.spring.universita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2025021701SpringUniversitaApplicationTests {

	@Test
	void contextLoads() {
	}

}
