package main;
@FunctionalInterface
interface ConcatenaStringhe {
	String concatena(String stringa1, String stringa2);
}