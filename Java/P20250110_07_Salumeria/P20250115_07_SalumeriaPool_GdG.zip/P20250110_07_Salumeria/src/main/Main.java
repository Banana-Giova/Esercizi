package main;
import models.*;

public class Main {

	public static void main(String[] args) {
		Bancone salumeria = new Bancone();
		salumeria.salumeria_aperta();
	}
}
