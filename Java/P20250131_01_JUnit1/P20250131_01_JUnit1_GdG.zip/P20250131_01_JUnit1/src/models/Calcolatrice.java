package models;

public class Calcolatrice {
		
	public static int somma(int a, int b) {
	return a + b;
		}

}