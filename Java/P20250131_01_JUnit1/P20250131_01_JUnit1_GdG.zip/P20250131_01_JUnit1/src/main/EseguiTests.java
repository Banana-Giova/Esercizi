package main;
import models.*;
import org.junit.jupiter.api.Test;


public class EseguiTests {
	
	@Test
	public void allTests() {
		CalcolatriceTest.testSomma();
	}
}