package com.spring.json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2025021401SpringProdottiApplicationTests {

	@Test
	void contextLoads() {
	}

}
