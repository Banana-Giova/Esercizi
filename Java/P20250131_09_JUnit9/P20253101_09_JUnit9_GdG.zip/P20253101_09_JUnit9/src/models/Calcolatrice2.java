package models;

public class Calcolatrice2 {
	public static int moltiplicazione(int a, int b) {
		return a * b;
	}
	public static double divisione(int a, int b) {
		return (double)a / (double)b;
	}
}
