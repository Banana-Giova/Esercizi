package models;

public class Calcolatrice1 {
		
	public static int somma(int a, int b) {
		return a + b;
	}
	public static int sottrazione(int a, int b) {
		return a - b;
	}
}