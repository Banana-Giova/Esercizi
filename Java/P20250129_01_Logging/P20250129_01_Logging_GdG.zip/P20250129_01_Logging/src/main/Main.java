package main;
import models.*;

public class Main {

	
	public static void main(String[] args) {
		
		Calcolatrice.somma(10, 20);
		Calcolatrice.sottrazione(10, 20);
		Calcolatrice.moltiplicazione(10, 20);
		Calcolatrice.divisione(10, 20);
	}
}