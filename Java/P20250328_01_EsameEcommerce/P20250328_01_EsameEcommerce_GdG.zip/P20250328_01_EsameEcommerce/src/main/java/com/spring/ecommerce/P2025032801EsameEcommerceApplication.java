package com.spring.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P2025032801EsameEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(P2025032801EsameEcommerceApplication.class, args);
	}

}
