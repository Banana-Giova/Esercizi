package com.spring.ecommerce.config;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
}
