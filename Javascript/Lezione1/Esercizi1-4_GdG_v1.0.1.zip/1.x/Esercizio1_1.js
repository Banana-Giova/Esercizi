let nome = "Giovanni di Giuseppe";
let showNome = () => {
    console.log(nome);
    document.getElementById("Esercizio_1").innerText = `Mi chiamo ${nome}!`;
};